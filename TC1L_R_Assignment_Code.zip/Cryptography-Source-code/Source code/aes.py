from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto.Random import get_random_bytes
import random
import time  # Import time module for performance measurement

# Function to generate RSA key pair for Person B
def generate_rsa_keys():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

# Function for Person A to generate a 256-bit AES key
def person_a_generate_aes_key():
    return get_random_bytes(32)

# Encrypt the AES key using Person B's RSA public key
def rsa_encrypt_aes_key(aes_key, rsa_public_key):
    rsa_key = RSA.import_key(rsa_public_key)
    cipher_rsa = PKCS1_OAEP.new(rsa_key)
    return cipher_rsa.encrypt(aes_key)

# Decrypt the AES key using Person B's RSA private key
def rsa_decrypt_aes_key(encrypted_aes_key, rsa_private_key):
    rsa_key = RSA.import_key(rsa_private_key)
    cipher_rsa = PKCS1_OAEP.new(rsa_key)
    return cipher_rsa.decrypt(encrypted_aes_key)

# Encrypt the plaintext manually using AES in CTR mode
def aes_encrypt_message_manual(aes_key, plaintext):
    block_size = 16  
    plaintext_bytes = plaintext.encode('utf-8')
    nonce = get_random_bytes(8)  
    ciphertext = bytearray()
    cipher_ecb = AES.new(aes_key, AES.MODE_ECB)
    
    n_blocks = (len(plaintext_bytes) + block_size - 1) // block_size
    
    for i in range(n_blocks):
        counter = i.to_bytes(8, byteorder='big')
        counter_block = nonce + counter
        keystream = cipher_ecb.encrypt(counter_block)
        
        start = i * block_size
        end = start + block_size
        block = plaintext_bytes[start:end]
        cipher_block = bytes(b ^ k for b, k in zip(block, keystream))
        ciphertext.extend(cipher_block)
    
    return nonce, bytes(ciphertext)

# Decrypt the ciphertext manually using AES in CTR mode
def aes_decrypt_message_manual(aes_key, nonce, ciphertext):
    block_size = 16
    plaintext_bytes = bytearray()
    cipher_ecb = AES.new(aes_key, AES.MODE_ECB)
    
    n_blocks = (len(ciphertext) + block_size - 1) // block_size
    
    for i in range(n_blocks):
        counter = i.to_bytes(8, byteorder='big')
        counter_block = nonce + counter
        keystream = cipher_ecb.encrypt(counter_block)
        
        start = i * block_size
        end = start + block_size
        block = ciphertext[start:end]
        plain_block = bytes(b ^ k for b, k in zip(block, keystream))
        plaintext_bytes.extend(plain_block)
    
    return plaintext_bytes.decode('utf-8')

# Function to introduce random bit errors into the ciphertext
def simulate_bit_error(ciphertext, num_errors=1):
    total_bits = len(ciphertext) * 8
    corrupted = bytearray(ciphertext)
    flipped_bits = []

    for _ in range(num_errors):
        random_bit_index = random.randint(0, total_bits - 1)
        byte_index = random_bit_index // 8
        bit_in_byte = random_bit_index % 8
        corrupted[byte_index] ^= 1 << bit_in_byte
        flipped_bits.append(random_bit_index)

    print(f"Flipped random bit positions: {flipped_bits}")
    return bytes(corrupted)

# Main function to run encryption, decryption, and error simulation with timing
def main():
    print("\n" + "=" * 50)
    print("          RSA KEY GENERATION FOR PERSON B")
    print("=" * 50)
    rsa_private, rsa_public = generate_rsa_keys()
    
    print("\n" + "=" * 50)
    print("           PERSON A GENERATES AES KEY")
    print("=" * 50)
    aes_key = person_a_generate_aes_key()
    
    print("\n" + "=" * 50)
    print("   ENCRYPT AES KEY WITH PERSON B'S RSA PUBLIC KEY")
    print("=" * 50)
    start = time.perf_counter()
    encrypted_aes_key = rsa_encrypt_aes_key(aes_key, rsa_public)
    rsa_encrypt_time = time.perf_counter() - start
    print(f"RSA Encryption Time: {rsa_encrypt_time:.6f} seconds")
    
    print("\n" + "=" * 50)
    print("  PERSON B DECRYPTS THE AES KEY USING RSA PRIVATE KEY")
    print("=" * 50)
    start = time.perf_counter()
    decrypted_aes_key = rsa_decrypt_aes_key(encrypted_aes_key, rsa_private)
    rsa_decrypt_time = time.perf_counter() - start
    print(f"RSA Decryption Time: {rsa_decrypt_time:.6f} seconds")
    assert aes_key == decrypted_aes_key, "AES key mismatch after RSA decryption!"

    print("\n" + "=" * 50)
    print("        AES CTR MODE ENCRYPTION (MANUAL)")
    print("=" * 50)
    message = input("Enter the message to encrypt: ")
    
    start = time.perf_counter()
    nonce, ciphertext = aes_encrypt_message_manual(aes_key, message)
    aes_encrypt_time = time.perf_counter() - start
    print(f"AES Encryption Time: {aes_encrypt_time:.6f} seconds")

    # Printing Nonce & Ciphertext
    print("Nonce (hex):", nonce.hex())
    print("Ciphertext (hex):", ciphertext.hex())

    print("\n" + "=" * 50)
    print("  PERSON B DECRYPTS THE MESSAGE WITH THE AES KEY")
    print("=" * 50)
    start = time.perf_counter()
    decrypted_message_by_b = aes_decrypt_message_manual(decrypted_aes_key, nonce, ciphertext)
    aes_decrypt_time = time.perf_counter() - start
    print(f"AES Decryption Time: {aes_decrypt_time:.6f} seconds")
    
    print("\nMessage decrypted by Person B:", decrypted_message_by_b)

    print("\n" + "=" * 50)
    print("         SIMULATING BIT ERROR IN CIPHERTEXT")
    print("=" * 50)
    num_errors = int(input("Enter the number of random bits to flip: "))
    corrupted_ciphertext = simulate_bit_error(ciphertext, num_errors=num_errors)

    print("\n" + "=" * 50)
    print("   ATTEMPT DECRYPTION OF CORRUPTED CIPHERTEXT")
    print("=" * 50)
    try:
        decrypted_corrupted_message = aes_decrypt_message_manual(aes_key, nonce, corrupted_ciphertext)
        print("Decrypted Message from Corrupted Ciphertext:", decrypted_corrupted_message)
    except Exception as e:
        print("Error during decryption of corrupted ciphertext:", e)

if __name__ == "__main__":
    main()
