# Cryptography Source Code

## Overview
This project implements **classical and modern cryptographic algorithms**, focusing on:  
✔ **Product Cipher (Affine + Columnar Transposition)** – A combination of substitution and transposition for encryption.  
✔ **Hybrid Cipher (AES-CTR + RSA Key Exchange)** – A secure encryption scheme using symmetric and asymmetric cryptography.  

The project includes **performance analysis, security evaluation, and bit error resilience testing**.

---

## Features
✔ **Affine Cipher & Columnar Transposition Encryption/Decryption**  
✔ **AES-CTR Mode Encryption & Decryption**  
✔ **RSA Key Exchange for Secure Key Distribution**  
✔ **Bit Error Simulation & Its Effect on Decryption**  
✔ **Performance Measurement of Encryption & Decryption Times**  

---

## 🛠 Installation

### **1. Clone the Repository**
```sh
git clone https://github.com/Beatz02/TC1L_R_Assignment_Code
cd /Cryptography-Source-code/Source-code
