from math import gcd
from sympy import mod_inverse
import time

# Affine Cipher Implementation
def affine_encrypt(text, a, b):
    """
    Encrypts the text using the Affine Cipher.
    Converts text to lowercase.
    """
    if gcd(a, 26) != 1:
        raise ValueError("Key 'a' must be coprime with 26.")
    
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            x = ord(char.lower()) - ord('a')
            encrypted_char = (a * x + b) % 26
            encrypted_text += chr(encrypted_char + ord('a'))
        else:
            encrypted_text += char
    return encrypted_text

def affine_decrypt(cipher, a, b):
    """
    Decrypts the cipher text using the Affine Cipher.
    """
    a_inv = mod_inverse(a, 26)  # Compute modular inverse of 'a'
    decrypted_text = ""
    for char in cipher:
        if char.isalpha():
            y = ord(char.lower()) - ord('a')
            decrypted_char = (a_inv * (y - b)) % 26
            decrypted_text += chr(decrypted_char + ord('a'))
        else:
            decrypted_text += char
    return decrypted_text

def validate_transposition_key(key):
    """
    Validates that the key is a permutation of numbers from 1 to len(key).
    """
    if sorted(key) != list(range(1, len(key) + 1)):
        raise ValueError("Transposition key must be a permutation of numbers from 1 to n, where n is the length of the key.")

# Columnar Transposition Cipher
def transposition_encrypt(text, key):
    """
    Encrypts the text using a Columnar Transposition Cipher.
    """
    validate_transposition_key(key)
    num_cols = len(key)
    num_rows = -(-len(text) // num_cols)  # Ceiling division

    # Fill the matrix row-by-row.
    matrix = []
    for i in range(num_rows):
        row = []
        for j in range(num_cols):
            idx = i * num_cols + j
            if idx < len(text):
                row.append(text[idx])
            else:
                row.append('')
        matrix.append(row)

    # Read the columns in the order defined by the sorted key.
    sorted_indices = sorted(range(num_cols), key=lambda i: key[i])
    cipher = ''
    for col in sorted_indices:
        for row in matrix:
            if row[col]:
                cipher += row[col]
    return cipher

def transposition_decrypt(cipher, key):
    """
    Decrypts the cipher text using a Columnar Transposition Cipher.
    """
    validate_transposition_key(key)
    num_cols = len(key)
    num_rows = -(-len(cipher) // num_cols)  # Ceiling division
    total_cells = num_cols * num_rows
    num_shaded_boxes = total_cells - len(cipher)
    
    # Determine the number of characters in each column (in natural order).
    full_cols = num_cols - num_shaded_boxes  # Columns that have full length.
    col_lengths = [num_rows if i < full_cols else num_rows - 1 for i in range(num_cols)]
    
    # Get the order of columns from the key.
    sorted_indices = sorted(range(num_cols), key=lambda i: key[i])
    cols = [''] * num_cols
    index = 0
    for col in sorted_indices:
        length = col_lengths[col]
        cols[col] = cipher[index:index+length]
        index += length

    # Reconstruct the plaintext by reading the matrix row-by-row.
    plaintext = ''
    for r in range(num_rows):
        for c in range(num_cols):
            if r < len(cols[c]):
                plaintext += cols[c][r]
    return plaintext

# Full Product Cipher Implementation (Affine followed by Transposition)
def product_cipher_encrypt(text, a, b, key):
    """
    Applies Affine Cipher encryption followed by Columnar Transposition encryption.
    Returns the intermediate Affine encrypted text and the final transposition encrypted text.
    """
    affine_encrypted = affine_encrypt(text, a, b)
    transposition_encrypted = transposition_encrypt(affine_encrypted, key)
    return affine_encrypted, transposition_encrypted

def product_cipher_decrypt(cipher, a, b, key):
    """
    Applies the reverse process: Columnar Transposition decryption followed by Affine decryption.
    Returns the final decrypted text.
    """
    transposition_decrypted = transposition_decrypt(cipher, key)
    affine_decrypted = affine_decrypt(transposition_decrypted, a, b)
    return affine_decrypted

# Example Usage with Timing and Separate Outputs for Analysis
if __name__ == "__main__":
    text = input("Enter text to encrypt: ")
    affine_a = int(input("Enter value for 'a' (must be coprime with 26): "))
    affine_b = int(input("Enter value for 'b': "))
    transposition_key = list(map(int, input("Enter transposition key (comma-separated numbers): ").split(',')))
    
    try:
        # Affine Cipher Timing
        start = time.perf_counter()
        affine_encrypted = affine_encrypt(text, affine_a, affine_b)
        affine_encrypt_time = time.perf_counter() - start

        start = time.perf_counter()
        affine_decrypted = affine_decrypt(affine_encrypted, affine_a, affine_b)
        affine_decrypt_time = time.perf_counter() - start

        # Columnar Transposition Cipher Timing (applied directly to original text)
        start = time.perf_counter()
        trans_encrypted = transposition_encrypt(text, transposition_key)
        trans_encrypt_time = time.perf_counter() - start

        start = time.perf_counter()
        trans_decrypted = transposition_decrypt(trans_encrypted, transposition_key)
        trans_decrypt_time = time.perf_counter() - start

        # Product Cipher Timing (Affine then Transposition)
        start = time.perf_counter()
        _, product_encrypted = product_cipher_encrypt(text, affine_a, affine_b, transposition_key)
        product_encrypt_time = time.perf_counter() - start

        start = time.perf_counter()
        product_decrypted = product_cipher_decrypt(product_encrypted, affine_a, affine_b, transposition_key)
        product_decrypt_time = time.perf_counter() - start

        # Improved Output Design
        print("\n" + "="*35)
        print("           AFFINE CIPHER")
        print("="*35)
        print(f"Encrypted Text    : {affine_encrypted}")
        print(f"Decrypted Text    : {affine_decrypted}")
        print(f"Encryption Time   : {affine_encrypt_time:.6f} seconds")
        print(f"Decryption Time   : {affine_decrypt_time:.6f} seconds")

        print("\n" + "="*35)
        print("  COLUMNAR TRANSPOSITION CIPHER")
        print("="*35)
        print(f"Encrypted Text    : {trans_encrypted}")
        print(f"Decrypted Text    : {trans_decrypted}")
        print(f"Encryption Time   : {trans_encrypt_time:.6f} seconds")
        print(f"Decryption Time   : {trans_decrypt_time:.6f} seconds")

        print("\n" + "="*35)
        print("  PRODUCT CIPHER (AFFINE -> TRANS)")
        print("="*35)
        print(f"Encrypted Text    : {product_encrypted}")
        print(f"Decrypted Text    : {product_decrypted}")
        print(f"Encryption Time   : {product_encrypt_time:.6f} seconds")
        print(f"Decryption Time   : {product_decrypt_time:.6f} seconds")

    except ValueError as ve:
        print("Error:", ve)




